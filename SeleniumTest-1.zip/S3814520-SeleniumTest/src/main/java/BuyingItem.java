import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class BuyingItem {
    public static void main(String[] args) throws InterruptedException {

        System.setProperty("webdriver.chrome.driver","//Users//karanpradhan//Downloads//chromedriver-mac-x64//chromedriver");

        WebDriver driver = new ChromeDriver();

        //1. Browse the Google page
        driver.get("https://petstore.octoperf.com");

        Thread.sleep(2000);

        //2. Locate the sign-in button and Click
        driver.findElement(By.linkText("Enter the Store")).click();

        Thread.sleep(2000);

        driver.findElement(By.linkText("Sign In")).click();

        Thread.sleep(2000);

        driver.findElement(By.xpath("/html/body/div[2]/div/form/p[2]/input[1]")).sendKeys("karan1"); // Will send values to user id
        Thread.sleep(2000);
        // Find the input element using XPath
        WebElement inputElement = driver.findElement(By.xpath("/html/body/div[2]/div/form/p[2]/input[2]"));

// Clear the value in the input field
        inputElement.clear();
        Thread.sleep(2000);

        driver.findElement(By.xpath("/html/body/div[2]/div/form/p[2]/input[2]")).sendKeys("karan1");

        Thread.sleep(2000);

        driver.findElement(By.xpath("/html/body/div[2]/div/form/input")).click();

        Thread.sleep(2000);
        driver.findElement(By.xpath("/html/body/div[1]/div[4]/a[1]/img")).click();

        Thread.sleep(2000);
        driver.findElement(By.xpath("/html/body/div[2]/div[2]/table/tbody/tr[2]/td[1]/a")).click();

        Thread.sleep(2000);
        driver.findElement(By.xpath("/html/body/div[2]/div[2]/table/tbody/tr[2]/td[1]/a")).click();

        Thread.sleep(2000);
        driver.findElement(By.xpath("/html/body/div[2]/div[2]/table/tbody/tr[7]/td/a")).click();

        Thread.sleep(2000);

        WebElement inputElement2 = driver.findElement(By.xpath("/html/body/div[2]/div[2]/div[1]/form/table/tbody/tr[2]/td[5]/input"));



// Clear the value in the input field
        inputElement2.clear();

        Thread.sleep(2000);

        driver.findElement(By.xpath("/html/body/div[2]/div[2]/div[1]/form/table/tbody/tr[2]/td[5]/input")).sendKeys("4");
        Thread.sleep(2000);

        driver.findElement(By.xpath("/html/body/div[2]/div[2]/div[1]/form/table/tbody/tr[3]/td[1]/input")).click(); // update cart
        Thread.sleep(2000);

        driver.findElement(By.xpath("/html/body/div[2]/div[2]/div[1]/a")).click();//proceed to check out
        Thread.sleep(2000);
        driver.findElement(By.xpath("/html/body/div[2]/div/form/input")).click(); // continue
        Thread.sleep(2000);
        driver.findElement(By.xpath("/html/body/div[2]/div[2]/a")).click();




    }
}
