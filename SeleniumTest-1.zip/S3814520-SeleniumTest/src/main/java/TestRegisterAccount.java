import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import java.util.Random;

public class TestRegisterAccount {
    public static void main(String[] args) throws InterruptedException {

        System.setProperty("webdriver.chrome.driver","//Users//karanpradhan//Downloads//chromedriver-mac-x64//chromedriver");

        WebDriver driver = new ChromeDriver();

        //1. Browse the Google page
        driver.get("https://petstore.octoperf.com");

        //2. Locate the sign-in button and Click
        driver.findElement(By.linkText("Enter the Store")).click();

        driver.findElement(By.linkText("Sign In")).click();

        driver.findElement(By.linkText("Register Now!")).click();

        String randomUsername = generateRandomUsername(8);


        driver.findElement(By.xpath("/html/body/div[2]/div/form/table[1]/tbody/tr[1]/td[2]/input")).sendKeys(randomUsername); // Will send values to First Name tab
        Thread.sleep(2000);
        driver.findElement(By.xpath("/html/body/div[2]/div/form/table[1]/tbody/tr[2]/td[2]/input")).sendKeys(randomUsername); // Will send values to First Name tab
        driver.findElement(By.xpath("/html/body/div[2]/div/form/table[1]/tbody/tr[3]/td[2]/input")).sendKeys("SerName"); // Will send values to last Name tab

        driver.findElement(By.xpath("/html/body/div[2]/div/form/table[2]/tbody/tr[1]/td[2]/input")).sendKeys(randomUsername); // Will send values to First Name
        driver.findElement(By.xpath("/html/body/div[2]/div/form/table[2]/tbody/tr[2]/td[2]/input")).sendKeys("lim"); // Will send values to last Name
        driver.findElement(By.xpath("/html/body/div[2]/div/form/table[2]/tbody/tr[3]/td[2]/input")).sendKeys("kenny@gmail.com"); // Will send values to email
        driver.findElement(By.xpath("/html/body/div[2]/div/form/table[2]/tbody/tr[4]/td[2]/input")).sendKeys("0123456789"); // Will send values to phone
        driver.findElement(By.xpath("/html/body/div[2]/div/form/table[2]/tbody/tr[5]/td[2]/input")).sendKeys("address 1"); // Will send values to address
        driver.findElement(By.xpath("/html/body/div[2]/div/form/table[2]/tbody/tr[7]/td[2]/input")).sendKeys("dandy"); // Will send values to city
        driver.findElement(By.xpath("/html/body/div[2]/div/form/table[2]/tbody/tr[8]/td[2]/input")).sendKeys("VIC"); // Will send values to state
        driver.findElement(By.xpath("/html/body/div[2]/div/form/table[2]/tbody/tr[9]/td[2]/input")).sendKeys("1234"); // Will send values to ZIP
        driver.findElement(By.xpath("/html/body/div[2]/div/form/table[2]/tbody/tr[10]/td[2]/input")).sendKeys("Australia"); // Will send values to county

        driver.findElement(By.xpath("/html/body/div[2]/div/form/input")).click();

    }

    private static String generateRandomUsername(int length) {
        String characters = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";
        StringBuilder randomUsername = new StringBuilder();
        Random random = new Random();

        for (int i = 0; i < length; i++) {
            int index = random.nextInt(characters.length());
            randomUsername.append(characters.charAt(index));
        }

        return randomUsername.toString();
    }
}
