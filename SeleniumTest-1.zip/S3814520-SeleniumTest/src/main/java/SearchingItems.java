import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class SearchingItems {
    public static void main(String[] args) {

        System.setProperty("webdriver.chrome.driver","//Users//karanpradhan//Downloads//chromedriver-mac-x64//chromedriver");

        WebDriver driver = new ChromeDriver();

        //1. Browse the Google page
        driver.get("https://petstore.octoperf.com");

        //2. Locate the sign-in button and Click
        driver.findElement(By.linkText("Enter the Store")).click();


        driver.findElement(By.xpath("/html/body/div[1]/div[3]/div/form/input[1]")).sendKeys("bulldog");

        driver.findElement(By.xpath("/html/body/div[1]/div[3]/div/form/input[2]")).click(); // click search button

        driver.findElement(By.xpath("/html/body/div[2]/div[2]/table/tbody/tr[2]/td[2]/b/a/font")).click(); // click on the productid

        driver.findElement(By.xpath("/html/body/div[2]/div[2]/table/tbody/tr[2]/td[5]/a")).click(); // click on the add cart of male adult bulldog

        driver.findElement(By.xpath("/html/body/div[2]/div[1]/a")).click();// return to main menu

        // Find the input element using XPath
        WebElement inputElement = driver.findElement(By.xpath("/html/body/div[1]/div[3]/div/form/input[1]"));

// Clear the value in the input field
        inputElement.clear();

        driver.findElement(By.xpath("/html/body/div[1]/div[3]/div/form/input[1]")).sendKeys("rattlesnake");

        driver.findElement(By.xpath("/html/body/div[1]/div[3]/div/form/input[2]")).click(); //click search button

        driver.findElement(By.xpath("/html/body/div[2]/div[2]/table/tbody/tr[2]/td[2]/b/a/font")).click(); //click product id
        driver.findElement(By.xpath("/html/body/div[2]/div[2]/table/tbody/tr[2]/td[5]/a")).click(); //click add cart for venomous rattle snake

        driver.findElement(By.xpath("/html/body/div[2]/div[2]/div[1]/form/table/tbody/tr[2]/td[8]/a")).click(); //click remove for bulldog

        driver.findElement(By.xpath("/html/body/div[2]/div[2]/div[1]/a")).click(); //click procede to check out without signin







    }
}
