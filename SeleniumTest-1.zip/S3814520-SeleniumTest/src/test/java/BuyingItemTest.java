import com.inflectra.spiratest.addons.junitextension.SpiraTestCase;
import com.inflectra.spiratest.addons.junitextension.SpiraTestConfiguration;
import org.junit.jupiter.api.*;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.time.Duration;


import static org.junit.jupiter.api.Assertions.*;
@SpiraTestConfiguration(
        url = "https://rmit.spiraservice.net/",
        login = "s3814520",
        rssToken = "{1C543953-A20C-4C4B-A325-CC5D98AB3724}",
        projectId = 94
)
@TestMethodOrder(MethodOrderer.OrderAnnotation.class)
public class BuyingItemTest {

    private static ChromeDriver driver;
    private String expectedResult;
    private String actualResult;
    private WebElement element;
    private WebDriverWait wait;

//    @BeforeEach
//    void setUp() throws InterruptedException {
//        // Add a thread sleep for 1.5 seconds (1500 milliseconds)
//        Thread.sleep(2500);
//    }



    @BeforeAll
    public static void setup()
    {
        System.setProperty("webdriver.chrome.driver","//Users//karanpradhan//Downloads//chromedriver-mac-x64//chromedriver");
        driver = new ChromeDriver();
        driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(20));
    }
    @Test
    @Order(1)
    @SpiraTestCase(testCaseId = 5402)
    public void testwebsite()
    {
        driver.get("https://petstore.octoperf.com");

        actualResult = "JPetStore Demo";
        expectedResult = driver.getTitle();
        assertEquals(expectedResult,actualResult);
    }


    @Test
    @Order(2)
    @SpiraTestCase(testCaseId = 5403)
    public void storePageTest()
    {
        driver.findElement(By.linkText("Enter the Store")).click();


        actualResult = "Sign In";
        WebElement WebElement = driver.findElement(By.xpath("/html/body/div[1]/div[2]/div/a[2]"));
        expectedResult = WebElement.getText();
        assertEquals(expectedResult,actualResult);
    }
    @Test
    @Order(3)
    @SpiraTestCase(testCaseId = 5404)
    public void signInPageTest()
    {
        driver.findElement(By.linkText("Sign In")).click();

        actualResult = "Please enter your username and password.";
        WebElement WebElement = driver.findElement(By.xpath("/html/body/div[2]/div/form/p[1]"));
        expectedResult = WebElement.getText();
        assertEquals(expectedResult,actualResult);
    }

    @Test
    @Order(4)
    @SpiraTestCase(testCaseId = 5405)
    public void signInTest()
    {
        driver.findElement(By.xpath("/html/body/div[2]/div/form/p[2]/input[1]")).sendKeys("karan1"); // Will send values to user id

        // Find the input element using XPath
        WebElement inputElement = driver.findElement(By.xpath("/html/body/div[2]/div/form/p[2]/input[2]"));

// Clear the value in the input field
        inputElement.clear();


        driver.findElement(By.xpath("/html/body/div[2]/div/form/p[2]/input[2]")).sendKeys("karan1");
        driver.findElement(By.xpath("/html/body/div[2]/div/form/input")).click();

        //Specify the amount of time driver should wait when searching for an element if it is not immediately present.
//        driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);

        actualResult = "Welcome Karan!";
        WebElement WebElement = driver.findElement(By.xpath("/html/body/div[2]/div[1]/div"));
        expectedResult = WebElement.getText();
        assertEquals(expectedResult,actualResult);
    }

    @Test
    @Order(5)
    @SpiraTestCase(testCaseId = 5406)
    public void clickItemFishTest()
    {
        driver.findElement(By.xpath("/html/body/div[1]/div[4]/a[1]/img")).click();

        //Specify the amount of time driver should wait when searching for an element if it is not immediately present.
//        driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);

        actualResult = "Fish";
        WebElement WebElement = driver.findElement(By.xpath("/html/body/div[2]/div[2]/h2"));
        expectedResult = WebElement.getText();
        assertEquals(expectedResult,actualResult);
    }


    @Test
    @Order(6)
    @SpiraTestCase(testCaseId = 5407)
    public void clickSelectedItemTest()
    {
        driver.findElement(By.xpath("/html/body/div[2]/div[2]/table/tbody/tr[2]/td[1]/a")).click();

        actualResult = "Angelfish";
        WebElement WebElement = driver.findElement(By.xpath("/html/body/div[2]/div[2]/h2"));
        expectedResult = WebElement.getText();
        assertEquals(expectedResult,actualResult);
    }


    @Test
    @Order(7)
    @SpiraTestCase(testCaseId = 5408)
    public void clickLargeAngleItemTest()
    {
        driver.findElement(By.xpath("/html/body/div[2]/div[2]/table/tbody/tr[2]/td[1]/a")).click();


        actualResult = "Large Angelfish";
        WebElement WebElement = driver.findElement(By.xpath("/html/body/div[2]/div[2]/table/tbody/tr[3]/td/b/font"));
        expectedResult = WebElement.getText();
        assertEquals(expectedResult,actualResult);
    }


    @Test
    @Order(8)
    @SpiraTestCase(testCaseId = 5409)
    public void clickAddCartTest()
    {
        driver.findElement(By.xpath("/html/body/div[2]/div[2]/table/tbody/tr[7]/td/a")).click();



        actualResult = "Shopping Cart";
        WebElement WebElement = driver.findElement(By.xpath("/html/body/div[2]/div[2]/div[1]/h2"));
        expectedResult = WebElement.getText();
        assertEquals(expectedResult,actualResult);
    }

    @Test
    @Order(9)
    @SpiraTestCase(testCaseId = 5410)
    public void changeQuantityTest()
    {
        WebElement inputElement2 = driver.findElement(By.xpath("/html/body/div[2]/div[2]/div[1]/form/table/tbody/tr[2]/td[5]/input"));
       // Clear the value in the input field
        inputElement2.clear();

        driver.findElement(By.xpath("/html/body/div[2]/div[2]/div[1]/form/table/tbody/tr[2]/td[5]/input")).sendKeys("4");
        driver.findElement(By.xpath("/html/body/div[2]/div[2]/div[1]/form/table/tbody/tr[3]/td[1]/input")).click();



        actualResult = "$66.00";
        WebElement WebElement = driver.findElement(By.xpath("/html/body/div[2]/div[2]/div[1]/form/table/tbody/tr[2]/td[7]"));
        expectedResult = WebElement.getText();
        assertEquals(expectedResult,actualResult);
    }

    @Test
    @Order(10)
    @SpiraTestCase(testCaseId = 5411)
    public void proceedToCheckoutTest()
    {
        driver.findElement(By.xpath("/html/body/div[2]/div[2]/div[1]/a")).click();

        actualResult = "Payment Details";
        WebElement WebElement = driver.findElement(By.xpath("/html/body/div[2]/div/form/table/tbody/tr[1]/th"));
        expectedResult = WebElement.getText();
        assertEquals(expectedResult,actualResult);
    }


    @Test
    @Order(11)
    @SpiraTestCase(testCaseId = 5412)
    public void ContinueButtonTest()
    {
        driver.findElement(By.xpath("/html/body/div[2]/div/form/input")).click(); // continue

        actualResult = "Order";
        WebElement WebElement = driver.findElement(By.xpath("/html/body/div[2]/div[2]/table/tbody/tr[1]/th/font[1]/b"));
        expectedResult = WebElement.getText();
        assertEquals(expectedResult,actualResult);
    }

    @Test
    @Order(12)
    @SpiraTestCase(testCaseId = 5413)
    public void ConfirmButtonTest()
    {
        driver.findElement(By.xpath("/html/body/div[2]/div[2]/a")).click();

        actualResult = "Thank you, your order has been submitted.";
        WebElement WebElement = driver.findElement(By.xpath("/html/body/div[2]/ul/li"));
        expectedResult = WebElement.getText();
        assertEquals(expectedResult,actualResult);
    }

    @AfterAll
        //closing the browser
        //all test classes
        public static void CloseBrowser()
        {
            driver.close();
        }

}