
import com.inflectra.spiratest.addons.junitextension.SpiraTestConfiguration;
import org.junit.jupiter.api.*;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.WebDriverWait;
import com.inflectra.spiratest.addons.junitextension.SpiraTestCase;
import java.time.Duration;
import java.util.Random;
import java.util.concurrent.TimeUnit;

import static org.junit.jupiter.api.Assertions.*;
@SpiraTestConfiguration(
        url = "https://rmit.spiraservice.net/",
        login = "s3814520",
        rssToken = "{1C543953-A20C-4C4B-A325-CC5D98AB3724}",
        projectId = 94
)
@TestMethodOrder(MethodOrderer.OrderAnnotation.class)
public class SearchingItemsTest {

    private static ChromeDriver driver;
    private String expectedResult;
    private String actualResult;
    private WebElement element;
    private WebDriverWait wait;
    private  static  String randomUsername;

//    @BeforeEach
//    void setUp() throws InterruptedException {
//        // Add a thread sleep for 1.5 seconds (1500 milliseconds)
//        Thread.sleep(2500);
//    }


    @BeforeAll
    public static void setup()
    {
        System.setProperty("webdriver.chrome.driver","//Users//karanpradhan//Downloads//chromedriver-mac-x64//chromedriver");
        driver = new ChromeDriver();
        driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(20));

    }
    @Test
    @Order(1)
    @SpiraTestCase(testCaseId = 5503)
    public void testGotoMainPage()
    {
        driver.get("https://petstore.octoperf.com");
        driver.findElement(By.linkText("Enter the Store")).click();


        actualResult = "Sign In";
        WebElement WebElement = driver.findElement(By.xpath("/html/body/div[1]/div[2]/div/a[2]"));
        expectedResult = WebElement.getText();
        assertEquals(expectedResult,actualResult);
    }

    @Test
    @Order(2)
    @SpiraTestCase(testCaseId = 5505)
    public void testSearchItemForDogInSearchBar()
    {
        driver.findElement(By.xpath("/html/body/div[1]/div[3]/div/form/input[1]")).sendKeys("bulldog");
        driver.findElement(By.xpath("/html/body/div[1]/div[3]/div/form/input[2]")).click();



        actualResult = "Bulldog";
        WebElement WebElement = driver.findElement(By.xpath("//html/body/div[2]/div[2]/table/tbody/tr[2]/td[3]"));
        expectedResult = WebElement.getText();
        assertEquals(expectedResult,actualResult);
    }

    @Test
    @Order(3)
    @SpiraTestCase(testCaseId = 5508)
    public void testAddBullDogInCart()
    {
        driver.findElement(By.xpath("/html/body/div[2]/div[2]/table/tbody/tr[2]/td[2]/b/a/font")).click(); // click on the productid

        driver.findElement(By.xpath("/html/body/div[2]/div[2]/table/tbody/tr[2]/td[5]/a")).click(); // click on the add cart of male adult bulldog



        actualResult = "Shopping Cart";
        WebElement WebElement = driver.findElement(By.xpath("/html/body/div[2]/div[2]/div[1]/h2"));
        expectedResult = WebElement.getText();
        assertEquals(expectedResult,actualResult);
    }

    @Test
    @Order(4)
    @SpiraTestCase(testCaseId = 5509)
    public void testClickIReturnToMainMenu()
    {
        driver.findElement(By.xpath("/html/body/div[2]/div[1]/a")).click();



        actualResult = "Saltwater, Freshwater";
        WebElement WebElement = driver.findElement(By.xpath("/html/body/div[2]/div[2]/div[1]/div"));
        expectedResult = WebElement.getText();
        assertTrue(expectedResult.contains(actualResult));
    }

    @Test
    @Order(5)
    @SpiraTestCase(testCaseId = 5510)
    public void testToSearchRattleSnakeUsingSearchBar()
    {
        // Find the input element using XPath
        WebElement inputElement = driver.findElement(By.xpath("/html/body/div[1]/div[3]/div/form/input[1]"));

        inputElement.clear();

        driver.findElement(By.xpath("/html/body/div[1]/div[3]/div/form/input[1]")).sendKeys("rattlesnake");

        driver.findElement(By.xpath("/html/body/div[1]/div[3]/div/form/input[2]")).click();



        actualResult = "Rattlesnake";
        WebElement WebElement = driver.findElement(By.xpath("/html/body/div[2]/div[2]/table/tbody/tr[2]/td[3]"));
        expectedResult = WebElement.getText();
        assertTrue(expectedResult.contains(actualResult));
    }

    @Test
    @Order(6)
    @SpiraTestCase(testCaseId = 5511)
    public void testAddRattleSnakeInCart()
    {
        driver.findElement(By.xpath("/html/body/div[2]/div[2]/table/tbody/tr[2]/td[2]/b/a/font")).click(); //click product id
        driver.findElement(By.xpath("/html/body/div[2]/div[2]/table/tbody/tr[2]/td[5]/a")).click(); //click add cart for venomous rattle snake



        actualResult = "Shopping Cart";
        WebElement WebElement = driver.findElement(By.xpath("/html/body/div[2]/div[2]/div[1]/h2"));
        expectedResult = WebElement.getText();
        assertEquals(expectedResult,actualResult);
    }

    @Test
    @Order(7)
    @SpiraTestCase(testCaseId = 5512)
    public void testRemoveBullDogInCart()
    {
        driver.findElement(By.xpath("/html/body/div[2]/div[2]/div[1]/form/table/tbody/tr[2]/td[8]/a")).click(); //click remove for bulldog



        actualResult = "Sub Total: $18.50";
        WebElement WebElement = driver.findElement(By.xpath("/html/body/div[2]/div[2]/div[1]/form/table/tbody/tr[3]/td[1]"));
        expectedResult = WebElement.getText();
        assertEquals(expectedResult,actualResult);
    }





    @AfterAll
    //closing the browser
    //all test classes
    public static void CloseBrowser()
    {
        driver.close();
    }




}