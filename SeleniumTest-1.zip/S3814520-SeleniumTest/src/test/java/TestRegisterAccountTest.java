import com.inflectra.spiratest.addons.junitextension.SpiraTestCase;
import com.inflectra.spiratest.addons.junitextension.SpiraTestConfiguration;
import org.junit.jupiter.api.*;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.time.Duration;
import java.util.Random;

import static org.junit.jupiter.api.Assertions.assertEquals;

@SpiraTestConfiguration(
        url = "https://rmit.spiraservice.net/",
        login = "s3814520",
        rssToken = "{1C543953-A20C-4C4B-A325-CC5D98AB3724}",
        projectId = 94
)


@TestMethodOrder(MethodOrderer.OrderAnnotation.class)
public class TestRegisterAccountTest {

    private static ChromeDriver driver;
    private String expectedResult;
    private String actualResult;
    private WebElement element;
    private WebDriverWait wait;
    private  static  String randomUsername;

//    @BeforeEach
//    void setUp() throws InterruptedException {
//        // Add a thread sleep for 1.5 seconds (1500 milliseconds)
//        Thread.sleep(4000);
//    }


    @BeforeAll
    public static void setup()
    {
        System.setProperty("webdriver.chrome.driver","//Users//karanpradhan//Downloads//chromedriver-mac-x64//chromedriver");
        driver = new ChromeDriver();
        driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(20));
         randomUsername = generateRandomUsername(8);


    }
    @Test
    @Order(1)
    @SpiraTestCase(testCaseId = 5544)
    public void testGotoSignInPage()
    {
        driver.get("https://petstore.octoperf.com");
        driver.findElement(By.linkText("Enter the Store")).click();
        driver.findElement(By.linkText("Sign In")).click();
        actualResult = "Please enter your username and password.";
        WebElement WebElement = driver.findElement(By.xpath("/html/body/div[2]/div/form/p[1]"));
        expectedResult = WebElement.getText();
        assertEquals(expectedResult,actualResult);
    }

    @Test
    @Order(2)
    @SpiraTestCase(testCaseId = 5545)
    public void testRegisterNowButton()
    {
        driver.findElement(By.linkText("Register Now!")).click();



        actualResult = "User Information";
        WebElement WebElement = driver.findElement(By.xpath("/html/body/div[2]/div/form/h3[1]"));
        expectedResult = WebElement.getText();
        assertEquals(expectedResult,actualResult);
    }

    @Test
    @Order(3)
    @SpiraTestCase(testCaseId = 5546)
    public void testRegisterNewUser() throws InterruptedException {


        driver.findElement(By.xpath("/html/body/div[2]/div/form/table[1]/tbody/tr[1]/td[2]/input")).sendKeys(randomUsername); // Will send values to First Name tab

        driver.findElement(By.xpath("/html/body/div[2]/div/form/table[1]/tbody/tr[2]/td[2]/input")).sendKeys(randomUsername); // Will send values to First Name tab
        driver.findElement(By.xpath("/html/body/div[2]/div/form/table[1]/tbody/tr[3]/td[2]/input")).sendKeys("SerName"); // Will send values to First Name tab

        driver.findElement(By.xpath("/html/body/div[2]/div/form/table[2]/tbody/tr[1]/td[2]/input")).sendKeys(randomUsername); // Will send values to First Name
        driver.findElement(By.xpath("/html/body/div[2]/div/form/table[2]/tbody/tr[2]/td[2]/input")).sendKeys("lim"); // Will send values to last Name
        driver.findElement(By.xpath("/html/body/div[2]/div/form/table[2]/tbody/tr[3]/td[2]/input")).sendKeys("kenny@gmail.com"); // Will send values to email
        driver.findElement(By.xpath("/html/body/div[2]/div/form/table[2]/tbody/tr[4]/td[2]/input")).sendKeys("0123456789"); // Will send values to phone
        driver.findElement(By.xpath("/html/body/div[2]/div/form/table[2]/tbody/tr[5]/td[2]/input")).sendKeys("address 1"); // Will send values to phone
        driver.findElement(By.xpath("/html/body/div[2]/div/form/table[2]/tbody/tr[7]/td[2]/input")).sendKeys("dandy"); // Will send values to city
        driver.findElement(By.xpath("/html/body/div[2]/div/form/table[2]/tbody/tr[8]/td[2]/input")).sendKeys("VIC"); // Will send values to state
        driver.findElement(By.xpath("/html/body/div[2]/div/form/table[2]/tbody/tr[9]/td[2]/input")).sendKeys("1234"); // Will send values to ZIP
        driver.findElement(By.xpath("/html/body/div[2]/div/form/table[2]/tbody/tr[10]/td[2]/input")).sendKeys("Australia"); // Will send values to county



        driver.findElement(By.xpath("/html/body/div[2]/div/form/input")).click(); //Click Save Account Information

        actualResult = "Sign In";
        WebElement WebElement = driver.findElement(By.xpath("/html/body/div[1]/div[2]/div/a[2]"));

        expectedResult = WebElement.getText();
        assertEquals(expectedResult,actualResult);
    }

    @Test
    @Order(4)
    @SpiraTestCase(testCaseId = 6194)
    public void testNewAccountSignIn() throws InterruptedException {
        driver.findElement(By.linkText("Sign In")).click();

        driver.findElement(By.xpath("/html/body/div[2]/div/form/p[2]/input[1]")).sendKeys(randomUsername); // Will send values to user id

        WebElement inputElement = driver.findElement(By.xpath("/html/body/div[2]/div/form/p[2]/input[2]"));

// Clear the value in the input field
        inputElement.clear();


        driver.findElement(By.xpath("/html/body/div[2]/div/form/p[2]/input[2]")).sendKeys(randomUsername);

//        Thread.sleep(4000);

        driver.findElement(By.xpath("/html/body/div[2]/div/form/input")).click();



        actualResult = "Welcome "+ randomUsername+"!";

        WebElement WebElement = driver.findElement(By.xpath("/html/body/div[2]/div[1]/div"));

        expectedResult = WebElement.getText();
        assertEquals(expectedResult,actualResult);
    }



    @AfterAll
    //closing the browser
    //all test classes
    public static void CloseBrowser()
    {
        driver.close();
    }

    private static String generateRandomUsername(int length) {
        String characters = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";
        StringBuilder randomUsername = new StringBuilder();
        Random random = new Random();

        for (int i = 0; i < length; i++) {
            int index = random.nextInt(characters.length());
            randomUsername.append(characters.charAt(index));
        }

        return randomUsername.toString();
    }


}